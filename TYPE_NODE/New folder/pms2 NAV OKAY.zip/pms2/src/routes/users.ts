// import   UserController  from '../controller/EmployeeController';
// import { join } from 'path';
// import { Router } from 'express';
// const router=Router()


// // router.get('/',async function(req,res){
// //     UserController.getLogin.then(data=>{
// //         res.send(data)
// //         //res.render('pages/departments',{data:data})
// //     })
// // })


// export default router;
