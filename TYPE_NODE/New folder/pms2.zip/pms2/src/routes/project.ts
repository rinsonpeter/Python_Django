
import ProjectController from '../controller/ProjectController'; 
import EmployeeController from '../controller/EmployeeController';


import { Router } from 'express';
const router=Router()


router.get('/',async function(req,res){
    console.log("inside routes employee");
    ProjectController.getProjects().then(data=>{
        res.send(data)
        //res.render('pages/prjAll',{data:data})
    })
})




export default router;