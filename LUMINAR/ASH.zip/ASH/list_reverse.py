lst=["c","c++","python","java","c#"]

print(lst[::-1])