import {Request,Response,NextFunction} from 'express'
import {getConnection,getRepository} from 'typeorm'
import { Department } from '../entity/Department'
import { Employee } from '../entity/Employee'
import { Project } from '../entity/Project'
import { WorksOn } from '../entity/worksOn'

export class ProjectController{
    static getProjects= async ()=>{
        console.log("inside routes project");
        
        console.log("inside controller employee");
        const emp=await getRepository(Project)
        .find();
        return emp;
    }

}    

export default ProjectController;