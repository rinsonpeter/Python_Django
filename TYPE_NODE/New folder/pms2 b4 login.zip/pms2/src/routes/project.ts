import ProjectController from "../controller/ProjectController";
import EmployeeController from "../controller/EmployeeController";

import { Router } from "express";
const router = Router();

router.get("/", async function (req, res) {
  console.log("inside routes project");
  ProjectController.getProjects().then((data) => {
    //res.send(data)
    res.render("pages/prjAll", { data: data });
  });
});

router.get("/create", async function (req, res) {
  res.render("pages/prjAdd");
});

router.post("/create", async function (req, res) {
    console.log("inside post create project")
  var input = req.body;
  var prjData = {
    pName : input.pName,
    startDate : input.startDate,
    duration : input.duration,
    budget : input.budget,
  };
  ProjectController.saveProject(prjData).then((data)=>
  {
  })
  res.redirect('/projects/')
});

router.get("/edit/:id", async function (req, res) {
  console.log(">>>inside routes edit project");
  var id = req.params.id;
  ProjectController.editProject(id).then((data) => {
    //res.send(data);
    res.render("pages/prjEdit", { data: data });
  });
});

router.post("/edit/:id", async function (req, res) {
    var input = req.body;
    var id = req.params.id;
    var prjData = {
            pName : input.pName,
            startDate : input.startDate,
            duration : input.duration,
            budget : input.budget
    };
    
    ProjectController.saveEditProject(prjData, id).then((data) => {
      res.redirect("/projects");
    });
  });

router.get("/info/:id", async function (req, res) {
  console.log(">>>inside routes info project");
  var id = req.params.id;
  ProjectController.infoProject(id).then((data) => {
    //console.log(data)
    //res.send(data)
    res.render("pages/prjInfo", { data: data });
  });
});

router.get("/delete/:id", async function (req, res) {
  var id = req.params.id;
  ProjectController.deleteProject(id).then((data) => {
    //console.log(data)
    //res.send(data)
    res.redirect("/projects");
  });
});

export default router;
