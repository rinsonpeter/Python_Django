import { Router } from 'express';
//import Project from './project';
import Employee from './employee';
import Department from './department';
import Users from './users'
import Project from './project';

const router=Router();

//router.use('/projects',Project);
router.use('/employees',Employee);
router.use('/departments',Department);
router.use('/users',Users);
router.use('/project',Project);



export default router;