import {Request,Response,NextFunction} from 'express'
import {getConnection,getRepository} from 'typeorm'
import { Department } from '../entity/Department'
import { Employee } from '../entity/Employee'
import { Project } from '../entity/Project'
import { WorksOn } from '../entity/worksOn'

export class ProjectController{
    static getProjects= async ()=>{
        
        console.log("inside controller employee");
        const emp=await getRepository(Project)
        .find();
        // .createQueryBuilder("dept")
        // .orderBy('dept.name')
        // .getMany();
        //console.log(emp);
        return emp;
        //res.render('pages/getAllEmp',{data:emp})
        
    }

}    

export default ProjectController;