import EmployeeController from '../controller/EmployeeController';
import { join } from 'path';
import { Router } from 'express';
const router=Router()

router.get('/create'),async function(req,res){
    console.log("inside add employee")
    EmployeeController.addEmployees().then(data=>{
        res.send(data)
        res.render('pages/empAdd',{data:data})
    })
}
router.get('/',async function(req,res){
    console.log("inside routes employee");
    EmployeeController.getEmployees().then(data=>{
        //res.send(data)
        res.render('pages/empAll',{data:data})
    })
})
router.post('/edit/:id/'),async function(req,res){
    console.log("inside save edit employee")
    var input=req.body;
    var id=req.params.id
    EmployeeController.saveEditEmployees(input,id).then(data=>{
        res.send(data)
    })
}

router.get('/info/:id',EmployeeController.infoEmployees);
router.get('/edit/:id',EmployeeController.editEmployees);

export default router;