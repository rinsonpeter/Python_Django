import { Request, Response, NextFunction } from "express";
import { getConnection, getRepository } from "typeorm";
import { Department } from "../entity/Department";
import { Employee } from "../entity/Employee";
import { Project } from "../entity/Project";
import { WorksOn } from "../entity/worksOn";

export class ProjectController {
  static getProjects = async () => {
    const emp = await getRepository(Project).find();
    return emp;
  };

  static saveProject = async (prjData) => {
    console.log("PRJDATA:::::::", prjData);
    const newPrj = await getRepository(Project)
      .createQueryBuilder("prj")
      .insert()
      .into(Project)
      .values(prjData)
      .execute();

    return newPrj;
  };
  static saveEditProject = async (myData, id) => {
    const editPrj = await getConnection()
      .createQueryBuilder()
      .update(Project)
      .set(myData)
      .where("project.id = :id", { id })
      .execute();
    return editPrj;
  };

  static editProject = async (id) => {
    const emp = await getRepository(Project)
    .find({ where: { id: id } });
    console.log(emp);
    return emp;
  };

  static infoProject = async (id) => {
    const prj: any = await getRepository(Project)
      .createQueryBuilder("prj")
      .leftJoinAndSelect("prj.ProjectWorkR", "worksOn")
      .leftJoinAndSelect("worksOn.WorkEmpR", "emp")
      .where("prj.id=:id", { id: id })
      .getOne();
    //console.log("prj details-----------------",prj)
    //console.log(prj.ProjectWorkR[0].WorkEmpR.name)
    return prj;
  };

  
  static deleteProject = async (id) => {
    console.log("inside controller delete emp")
    await getConnection()
    .createQueryBuilder()
    .delete()
    .from(Project)
    .where("id = :id", { id: id })
    .execute();
    return
  };
}


export default ProjectController;
