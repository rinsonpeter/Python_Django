import  { UserController } from '../controller/UserController';
import { join } from 'path';
import { Router } from 'express';
const router=Router()


// router.get('/',async function(req,res){
//     UserController.all.then(data=>{
//         res.send(data)
//         //res.render('pages/departments',{data:data})
//     })
// })

// router.get('/',UserController.)

export default router;
