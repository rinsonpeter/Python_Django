import { Router } from 'express';
//import Project from './project';
import Employee from './employee';
import Department from './department';
import Users from './users'
import Project from './project';

const router=Router();

router.use('/employees',Employee);
router.use('/departments',Department);
router.use('/users',Users);
router.use('/projects',Project);



export default router;